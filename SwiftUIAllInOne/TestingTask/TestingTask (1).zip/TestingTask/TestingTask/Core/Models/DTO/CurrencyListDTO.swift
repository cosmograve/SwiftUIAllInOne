//
//  CurrencyListDTO.swift
//  TestingTask
//
//  Created by Dima Bykov on 19.07.2022.
//

import Foundation
struct CurrencyListDTO: Codable {
    let message: String
    let data: [String]
}
