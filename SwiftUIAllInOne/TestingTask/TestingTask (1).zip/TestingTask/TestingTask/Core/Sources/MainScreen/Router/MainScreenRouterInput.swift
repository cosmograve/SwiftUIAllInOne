//
//  MainScreenRouterInput.swift
//  TestingTask
//
//  Created by DBykov on 19/07/2022.
//

import Foundation

protocol MainScreenRouterInput {

}
